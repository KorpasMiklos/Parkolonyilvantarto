export interface Jarmu{
    id? : number;
    rendszam : string;
    szin : string;
    tipus : string;
    tulajdonos : string;
}
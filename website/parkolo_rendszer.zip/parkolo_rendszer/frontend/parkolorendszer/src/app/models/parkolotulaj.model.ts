export interface Parkolotulaj{
    id? : number;
    nev : string;
    telefonszam : string;
    email_cim : string;
}
export interface Berles {
  id?: number;
  parkolo_id: number;
  tulaj_id: number | null;
  berles_kezdete: string | null; // date
  berles_vege: string | null;    // date
  ar: number | null;
}
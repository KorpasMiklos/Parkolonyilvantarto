import { TestBed } from '@angular/core/testing';

import { ParkoloService } from './parkolo.service';

describe('ParkoloService', () => {
  let service: ParkoloService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ParkoloService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

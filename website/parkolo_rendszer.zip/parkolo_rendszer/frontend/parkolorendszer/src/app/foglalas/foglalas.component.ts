import { Component, Input,Output,EventEmitter, OnInit } from '@angular/core';
import { Parkolas } from '../models/parkolas.model';
import { Berles } from '../models/berles.model';
import { ParkoloService } from '../parkolo.service';
import { Jarmu } from '../models/jarmu.model';

@Component({
  selector: 'app-foglalas',
  standalone: false,
  templateUrl: './foglalas.component.html',
  styleUrl: './foglalas.component.css'
})
export class FoglalasComponent implements OnInit{

@Input() parkolo!: any;
@Output() close = new EventEmitter<void>();

jarmuvek : Jarmu[] = [];

tipus : 'parkolas' | 'berles' | null = null;

parkolas : Parkolas | null = null;
berles : Berles | null = null;

constructor(private parkoloService : ParkoloService){}

ngOnInit(): void {
  this.parkoloService.getJarmuvek().subscribe(data => {
    this.jarmuvek = data;
  });
}

tipusValasztas(tipus : 'parkolas' | 'berles'){
  this.tipus = tipus;

  if(tipus === 'parkolas'){
    this.parkolas = {
      jarmu_id : null,
      parkolo_id : this.parkolo.id,
      parkolas_kezdete : null,
      parkolas_vege : null,
      parkolas_idotartama : null 
    };
  }

  if(tipus === 'berles'){
    this.berles = {
      parkolo_id : this.parkolo.id,
      tulaj_id : null,
      berles_kezdete : null,
      berles_vege : null,
      ar : null
    };
  }
}

mentes() : void{
  if(this.tipus === 'parkolas' && this.parkolas){
    this.parkoloService.addParkolas(this.parkolas).subscribe({
    next : (res) => {
      console.log('Parkolás sikeresen mentve',res);
      this.close.emit(); //MODAL BEZÁRÁSA
    },
    error: (err) => {
      console.error('Parkolás mentési hiba', err);
      alert('Nem sikerült a parkolás mentése!');
    }
  });

}

if(this.tipus === 'berles' && this.berles){
  this.parkoloService.addBerles(this.berles).subscribe({
    next : (res) => {
      console.log('Bérlés sikeresen mentve?:', res);
      this.close.emit();
    },
    error : (err) => {
      console.error('Bérlés mentési hiba:', err);
      alert('Nem sikerült a bérlés mentése!');
    }
  });
}

}

bezaras(): void {
  this.tipus = null;
  this.parkolas = null;
  this.berles = null;
  this.close.emit();
}

}

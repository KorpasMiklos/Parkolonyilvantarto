import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddParkoloComponent } from './add-parkolo.component';

describe('AddParkoloComponent', () => {
  let component: AddParkoloComponent;
  let fixture: ComponentFixture<AddParkoloComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddParkoloComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddParkoloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

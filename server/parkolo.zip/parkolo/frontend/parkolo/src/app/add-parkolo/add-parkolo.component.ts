import { Component, OnInit } from '@angular/core';
import { ParkoloService } from '../parkolo.service';

@Component({
  selector: 'app-add-parkolo',
  standalone: false,
  templateUrl: './add-parkolo.component.html',
  styleUrl: './add-parkolo.component.css'
})
export class AddParkoloComponent implements OnInit{

  newCar = {rendszam:'',szin:'',tipus:'',tulajdonos:''};

  constructor(private parkoloService : ParkoloService){}

  ngOnInit(): void {
    //
  }

  addCar() : void{
    this.parkoloService.addCar(this.newCar).subscribe(() => {
      this.newCar = {rendszam:'',szin:'',tipus:'',tulajdonos:''};
    });
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ParkoloService {

  private apiUrl = 'http://localhost:3000/api/jarmu';

  constructor(private http : HttpClient) { }

  addCar(car : any) : Observable<any>{
    return this.http.post<any>(this.apiUrl, car);
  }
}

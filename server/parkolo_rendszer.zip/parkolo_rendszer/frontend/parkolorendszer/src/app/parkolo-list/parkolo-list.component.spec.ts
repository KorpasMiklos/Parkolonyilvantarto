import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkoloListComponent } from './parkolo-list.component';

describe('ParkoloListComponent', () => {
  let component: ParkoloListComponent;
  let fixture: ComponentFixture<ParkoloListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ParkoloListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParkoloListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

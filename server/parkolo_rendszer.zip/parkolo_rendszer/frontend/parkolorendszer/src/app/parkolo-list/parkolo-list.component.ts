import { Component, OnInit } from '@angular/core';
import { ParkoloService } from '../parkolo.service';

@Component({
  selector: 'app-parkolo-list',
  standalone: false,
  templateUrl: './parkolo-list.component.html',
  styleUrl: './parkolo-list.component.css'
})
export class ParkoloListComponent implements OnInit{

  parkolok : any[] = [];
  jarmuvek : any[] = [];
  parkolasok : any[] = [];
  parkolotulajok : any = [];
  berlesek : any[] = [];
  szabad_parkolok : any[] = [];
  foglalt_parkolok : any[] = [];
  berelt_parkolok : any[] = [];

  newJarmu = {rendszam:'',szin:'',tipus:'',tulajdonos:''};
  newTulaj = {nev:'',telefonszam:'',email_cim:''};
  newBerles = {parkolo_id:'',tulaj_id:'',berles_kezdete:'',berles_vege:'',ar:''};
  newParkolas = {jarmu_id:'',parkolo_id:'',parkolas_kezdete:'',parkolas_vege:'',parkolas_idotartama:''};

  editMode = false;
  editId : number | null = null;

  constructor(private parkoloService : ParkoloService){}

  ngOnInit(): void {
    this.loadParkolok();
    this.loadJarmuvek();
    this.loadParkolasok();
    this.loadParkolotulajok();
    this.loadBerlesek();
    this.loadSzabadParkolok();
    this.loadFoglaltParkolok();
    this.loadBereltParkolok();
  }

  //Összes parkoló
  loadParkolok() : void{
    this.parkoloService.getParkolok().subscribe(data => {
      this.parkolok = data;
    });
  }

  //Összes jármű
  loadJarmuvek() : void{
    this.parkoloService.getJarmuvek().subscribe(data => {
      this.jarmuvek = data;
    });
  }

  //Összes parkolás
  loadParkolasok() : void{
    this.parkoloService.getParkolasok().subscribe(data => {
      this.parkolasok = data;
    });
  }

  //Összes parkolótulaj
  loadParkolotulajok() : void{
    this.parkoloService.getParkolotulajok().subscribe(data => {
      this.parkolotulajok = data;
    });
  }

  //Összes bérlés
  loadBerlesek() : void {
    this.parkoloService.getBerlesek().subscribe(data => {
      this.berlesek = data;
    });
  }

  //Szabad parkolók
  loadSzabadParkolok() : void{
    this.parkoloService.getSzabadParkolok().subscribe(data => {
      this.szabad_parkolok = data;
    });
  }

  //Foglalt parkolók
  loadFoglaltParkolok() : void{
    this.parkoloService.getFoglaltParkolok().subscribe(data => {
      this.foglalt_parkolok = data;
    });
  }

//Berelt Parkolók
  loadBereltParkolok() : void{
    this.parkoloService.getBereltParkolok().subscribe(data => {
      this.berelt_parkolok = data;
    });
  }

  //POST jarmű
  addJarmu() : void{
    this.parkoloService.addJarmu(this.newJarmu).subscribe(() => {
      this.loadJarmuvek();
    });
  }

  //POST tulaj
  addTulaj() : void{
    this.parkoloService.addParkolotulaj(this.newTulaj).subscribe(() => {
      this.loadParkolotulajok();
    });
  }

  //POST bérlés
  addBerles() : void{
    this.parkoloService.addBerles(this.newBerles).subscribe(() => {
      this.loadBerlesek();
    })
  }

  //POST parkolás
  addParkolas() : void{
    this.parkoloService.addParkolas(this.newParkolas).subscribe(() => {
      this.loadParkolasok();
    })
  }

  startEditParkolas(parkolas : any) : void{
    this.editMode = true;
    this.editId = parkolas.id;
    this.newParkolas = {...parkolas};
  }

  startEditBerles(berles : any) : void{
    this.editMode = true;
    this.editId = berles.id;
    this.newBerles = {...berles};
  }

  updateParkolas() : void{
    this.parkoloService.updateParkolas(this.editId!, this.newParkolas).subscribe(() => {
      this.loadParkolasok();
      this.editMode = false;
      this.editId = null;
      this.newParkolas = {jarmu_id:'',parkolo_id:'',parkolas_kezdete:'',parkolas_vege:'',parkolas_idotartama:''};
    });
  }

  updateBerles() : void{
    this.parkoloService.updateBerles(this.editId!, this.newBerles).subscribe(() => {
      this.loadBerlesek();
      this.editMode = false;
      this.editId = null;
      this.newBerles = {parkolo_id:'',tulaj_id:'',berles_kezdete:'',berles_vege:'',ar:''};
    });
  }


}
